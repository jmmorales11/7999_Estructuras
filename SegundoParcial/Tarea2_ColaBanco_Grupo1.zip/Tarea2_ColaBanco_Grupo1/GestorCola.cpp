/*************************
UFA - ESPE
AUTORES: Matías Padrón,Sebastian Torres, Cristhoper Villamarin, Paola Moncayo, Camilo Orrico, Jeimy Morales, Ariel Guevera
FECHA DE CREACIÓN: 19/12/2022
FECHA DE MODIFICACIÓN: 19/12/2022
Grupo1-Gestión ba	nco usando Colas
GITHUB: Grupo-1-Estructura-de-datos-7999
 *************************/

#include "Menu.cpp"
#include <iostream>
using namespace std;
int main() {
	Menu objM;
	objM.menuPrincipal();
    return 0;
}
