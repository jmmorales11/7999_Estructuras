var searchData=
[
  ['tampantalla_0',['tamPantalla',['../class_arbol_radix.html#a42cf8643051efe1bdab4fda9cbf39403',1,'ArbolRadix']]]
];
