var searchData=
[
  ['setfinalpalabra_0',['setFinalPalabra',['../class_nodo.html#a9c3a10cb79f218105a310b77f127038d',1,'Nodo']]],
  ['sethijos_1',['setHijos',['../class_nodo.html#aac5c389eef42d40fe573960020db610c',1,'Nodo']]],
  ['setpalabra_2',['setPalabra',['../class_nodo.html#aeb2768d1dd931f202273fff20d4a859a',1,'Nodo']]]
];
