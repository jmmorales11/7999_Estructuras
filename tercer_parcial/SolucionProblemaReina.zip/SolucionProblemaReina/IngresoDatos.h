#include <string>
#include <iostream>
class IngresoDatos
{
public:

     virtual int IngresarDatosEntero();  
};