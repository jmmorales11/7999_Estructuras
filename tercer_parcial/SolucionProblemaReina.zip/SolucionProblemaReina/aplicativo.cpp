#include "menu.cpp"

int main(int argc, char **argv){
	MenuPrincipal();
	return 0;
}
