var searchData=
[
  ['cubomagico_0',['CuboMagico',['../class_cubo_magico.html#ae198f9063ffeb6d74d4e432af6425acd',1,'CuboMagico']]]
];
