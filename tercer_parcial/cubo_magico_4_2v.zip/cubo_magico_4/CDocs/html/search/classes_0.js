var searchData=
[
  ['cubo_0',['Cubo',['../class_cubo.html',1,'']]],
  ['cubomagico_1',['CuboMagico',['../class_cubo_magico.html',1,'']]]
];
