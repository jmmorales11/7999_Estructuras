var searchData=
[
  ['_7ecubomagico_0',['~CuboMagico',['../class_cubo_magico.html#a74129d3c44477516d2c3b72a1ac432de',1,'CuboMagico']]]
];
