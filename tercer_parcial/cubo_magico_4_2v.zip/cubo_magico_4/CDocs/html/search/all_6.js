var searchData=
[
  ['setcuadrado_0',['setCuadrado',['../class_cubo_magico.html#af490420ba9a0fe0c40fe2059fa9205c7',1,'CuboMagico']]],
  ['suma_1',['suma',['../class_cubo.html#a5bbedc52ca0264187c25217b2ecef0f0',1,'Cubo::suma()'],['../class_funciones_cubo.html#a1b8e2c136e8a367bcd00e45f92379e90',1,'FuncionesCubo::suma()']]]
];
