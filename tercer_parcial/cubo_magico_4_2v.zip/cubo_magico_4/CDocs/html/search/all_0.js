var searchData=
[
  ['cubo_0',['Cubo',['../class_cubo.html',1,'']]],
  ['cubo_2eh_1',['Cubo.h',['../_cubo_8h.html',1,'']]],
  ['cubomagico_2',['CuboMagico',['../class_cubo_magico.html',1,'CuboMagico'],['../class_cubo_magico.html#ae198f9063ffeb6d74d4e432af6425acd',1,'CuboMagico::CuboMagico()']]],
  ['cubomagico_2eh_3',['CuboMagico.h',['../_cubo_magico_8h.html',1,'']]]
];
