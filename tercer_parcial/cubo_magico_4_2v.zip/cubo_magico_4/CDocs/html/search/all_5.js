var searchData=
[
  ['mostrar_0',['mostrar',['../class_cubo.html#a7aa66364b38d8c0466bd924ce1fcd6f6',1,'Cubo::mostrar()'],['../class_funciones_cubo.html#ade5a4ffb9672be1a204caf07529794e7',1,'FuncionesCubo::mostrar(int)']]],
  ['mostrar1_1',['mostrar1',['../class_funciones_cubo.html#ac4253accb8d80012a75b260cbe8b4e20',1,'FuncionesCubo']]],
  ['mostrar2_2',['mostrar2',['../class_funciones_cubo.html#a4982a4cbb695894ae2ebc1683c502227',1,'FuncionesCubo']]]
];
