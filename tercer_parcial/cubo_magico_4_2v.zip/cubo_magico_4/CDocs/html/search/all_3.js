var searchData=
[
  ['getcuadrado_0',['getCuadrado',['../class_cubo_magico.html#a7212647011354edce721afe4a912e992',1,'CuboMagico']]]
];
